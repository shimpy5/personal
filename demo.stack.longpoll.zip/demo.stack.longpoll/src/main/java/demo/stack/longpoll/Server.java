package demo.stack.longpoll;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.google.common.util.concurrent.ListeningExecutorService;
import com.google.common.util.concurrent.MoreExecutors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sound.sampled.BooleanControl;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Server {
    private static final Logger LOGGER = LoggerFactory.getLogger(Server.class);

    public ServerSocket init() {
        try {
            return new ServerSocket(8082);

        }catch (Exception e) {
            e.printStackTrace();
        }return null;


    }
    AcceptorTask task = new AcceptorTask(false, init());

    static class TerminatorThread extends Thread {
        Server srvr;
        TerminatorThread(Server srvr) {
            this.srvr = srvr;
        }
        public void run() {
            srvr.shutdown();
            System.exit(1);
        }

    }
    class PushTask implements Callable {

        BlockingStack stack;
        Item item;
        PushTask(BlockingStack stack, Item item){
            this.stack = stack;
            this.item = item;
        }
        @Override
        public Boolean call() {
            boolean added =  stack.push(item);
            return added;

        }
    }
    class PopTask implements Callable {

        BlockingStack stack;

        PopTask(BlockingStack stack){
            this.stack = stack;
        }
        @Override
        public Item call() {
            return stack.pop();
        }

    }
    class ItemResponseWriter implements Runnable{
        Socket clntSock;
        ListenableFuture<Item> future;
        ItemResponseWriter(Socket clntSock, ListenableFuture<Item> future) {
            this.clntSock = clntSock;
            this.future = future;
        }
        @Override
        public void run() {
            try {
                Item response = future.get();

                if (response != null) {
                    String s = new String(response.getPayload());
                    LOGGER.debug("Popping {}", s);
                    clntSock.getOutputStream().write(response.getPayload());
                    clntSock.getOutputStream().flush();
                }else {
                    LOGGER.debug("Response is null");
                }
                //...process web site contents
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                try {
                    clntSock.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class PushResponseWriter implements Runnable{
        Socket clntSock;
        ListenableFuture<Boolean> future;
        PushResponseWriter(Socket clntSock, ListenableFuture<Boolean> future) {
            this.clntSock = clntSock;
            this.future = future;
        }
        @Override
        public void run() {
            try {
                Boolean response = future.get();
                if(response != null && response.booleanValue() == true) {
                    LOGGER.debug("Push Task finished");
                    clntSock.getOutputStream().write(0X00);
                }
                //...process web site contents
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    clntSock.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    class ReadTask implements Runnable {
        AtomicInteger connectionCount;
        Socket m_clntSock;
        BlockingStack stack;
        ListeningExecutorService stackService;
        ConcurrentHashMap<Socket, Long> socketTracker;
        ConcurrentLinkedQueue<Socket> linkedQueue;

        ReadTask(Socket clntSock, AtomicInteger connectionCount,
                 BlockingStack st, ExecutorService stackService, ConcurrentHashMap<Socket, Long> socketTracker, ConcurrentLinkedQueue<Socket> linkedQueue) {
            this.m_clntSock = clntSock;
            this.connectionCount = connectionCount;
            this.stack = st;
            this.stackService = MoreExecutors.listeningDecorator(stackService);
            this.socketTracker = socketTracker;
            this.linkedQueue = linkedQueue;
        }

        public void run() {
            ByteArrayInputStream dataInp = null;
            BufferedReader reader = null;
            DataOutputStream outputStream = null;
            BufferedWriter writer = null;

            try {
                byte []buffer = new byte[128];
                int offset = 0;
                int numBytes = m_clntSock.getInputStream().read(buffer, offset, 1);
                ListenableFuture<Boolean> pushFuture = null;
                ListenableFuture<Item> popFuture = null;
                while(numBytes > -1) {
                    byte b = buffer[0];
                    int val = b&0XFF;
                    if(val >= 128 && val <= 255) {

                        popFuture = stackService.submit(new PopTask(stack));
                        popFuture.addListener(new ItemResponseWriter(m_clntSock, popFuture), stackService);
                        //LOGGER.debug("Starting pop task");

                    } else if(val > 0 && val <= 127) {
                        int length = val;
                        offset+=1;
                       while((numBytes = m_clntSock.getInputStream().read(buffer, offset, val)) > -1
                               && numBytes < val) {
                           offset += numBytes;
                           val = val - numBytes;
                       }
                       if(numBytes > -1) {
                           byte[] payload = Arrays.copyOf(buffer, length+1);
                           String s = new String(payload);
                           Item newItem = new Item(payload, m_clntSock);
                           pushFuture = stackService.submit(new PushTask(stack, newItem));
                           pushFuture.addListener(new PushResponseWriter(m_clntSock, pushFuture), stackService);
                       }

                    }
                    offset = 0;
                    numBytes = m_clntSock.getInputStream().read(buffer, offset, 1);
                    //LOGGER.debug("Bytes read = %d", numBytes);
                }
                if(numBytes == -1) {
                    if(pushFuture != null && pushFuture.isDone() == false) {
                        pushFuture.cancel(true);

                    }
                    if(popFuture != null && popFuture.isDone() == false) {
                        popFuture.cancel(true);

                    }
                }

            } catch (IOException excp) {

            } finally {
                socketTracker.remove(m_clntSock);
                linkedQueue.remove(m_clntSock);
                try {
                    //m_clntSock.close();
                    connectionCount.decrementAndGet();
                    LOGGER.debug("Finally Called connection count is {} :", connectionCount.get());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public class WorkerThreadFactory implements ThreadFactory {
        private int counter = 0;
        private String prefix = "";

        public WorkerThreadFactory(String prefix) {
            this.prefix = prefix;
        }

        public Thread newThread(Runnable r) {
            return new Thread(r, prefix + "-" + counter++);
        }
    }

    class AcceptorTask implements Runnable {
        boolean shutdown;
        ServerSocket ss;
        AtomicInteger connectionCount = new AtomicInteger();
        ConcurrentLinkedQueue<Socket> linkedQueue = new ConcurrentLinkedQueue<>();
        ConcurrentHashMap<Socket, Long> map  = new ConcurrentHashMap<>();
        ExecutorService srvc = Executors.newFixedThreadPool(101, new WorkerThreadFactory("ReadSocketThread"));
        BlockingStack st = new BlockingStack(100);
        ExecutorService stackThreads = Executors.newFixedThreadPool(100, new WorkerThreadFactory("StackThread"));

        AcceptorTask(boolean shutdown, ServerSocket ss) {
            this.shutdown = shutdown;
            this.ss = ss;
        }

        public void shutdown(boolean stop) {
            shutdown = stop;
            while(true) {
                try {
                    srvc.shutdown();
                    if (srvc.awaitTermination(5, TimeUnit.SECONDS)) {
                        break;
                    }
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }
            while(linkedQueue.size() > 0) {
                Socket s = linkedQueue.poll();
                map.remove(s);
                try {
                    s.close();
                }catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }
        public void run() {
            try {
                while (!shutdown) {
                    try {
                        Socket cs = ss.accept();
                        LOGGER.debug("Connection Count at the start is: {} :", connectionCount.get());
                        int count = connectionCount.incrementAndGet();
                        LOGGER.debug("Connection Count after increment is: {} :", connectionCount.get());
                        Socket oldestSocket = linkedQueue.peek();
                        long oldestSocketTime = 0;
                        if (oldestSocket != null && count > 100) {
                            LOGGER.warn("\n Count of sockets is more than 100 thread");
                            oldestSocketTime = System.currentTimeMillis() - map.get(oldestSocket);

                            LOGGER.warn("\n OldestSocketTime is : {} ", oldestSocketTime);
                            if(oldestSocketTime > 10000) {
                                LOGGER.warn("\n Removing oldest socket");
                                linkedQueue.poll();
                                oldestSocket.close();
                                map.remove(oldestSocket);
                                linkedQueue.offer(cs);
                                ReadTask rt = new ReadTask(cs, connectionCount, st, stackThreads, map, linkedQueue);
                                srvc.submit(rt);

                            } else {
                                LOGGER.warn("\n Sending busy byte");
                                byte[] buffer = new byte[1];
                                buffer[0] = (byte) 0XFF;
                                cs.getOutputStream().write(buffer[0]);
                                cs.close();
                                connectionCount.decrementAndGet();
                            }

                        } else {
                            linkedQueue.offer(cs);
                            map.putIfAbsent(cs, System.currentTimeMillis());
                            ReadTask rt = new ReadTask(cs, connectionCount, st, stackThreads, map, linkedQueue);
                            srvc.submit(rt);
                        }
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        shutdown = false;
                    }


                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void start() {
        Thread t = new Thread(task);
        t.start();

    }

    public void shutdown() {
        task.shutdown(true);

    }

    public static void main(String []args) {

        Server s = new Server();
        TerminatorThread thr = new TerminatorThread(s);
        s.start();
        Runtime.getRuntime().addShutdownHook(thr);
    }
}
