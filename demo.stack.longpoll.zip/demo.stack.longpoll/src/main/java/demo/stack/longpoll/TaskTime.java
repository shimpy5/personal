package demo.stack.longpoll;

import com.google.common.util.concurrent.ListenableFuture;

public class TaskTime {
    long timestamp;
    ListenableFuture<Boolean> pushFuture;
    ListenableFuture<Item> popFuture;

    TaskTime(long timestamp, ListenableFuture<Boolean> pushFuture, ListenableFuture<Item> popFuture) {
        this.timestamp = timestamp;
        this.pushFuture = pushFuture;
        this.popFuture = popFuture;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public ListenableFuture<Boolean> getPushFuture() {
        return pushFuture;
    }

    public ListenableFuture<Item> getPopFuture() {
        return popFuture;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public void setPopFuture(ListenableFuture<Item> popFuture) {
        this.popFuture = popFuture;
    }

    public void setPushFuture(ListenableFuture<Boolean> pushFuture) {
        this.pushFuture = pushFuture;
    }
}
