package demo.stack.longpoll;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.Socket;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

public class BlockingStack {
    BlockingDeque<Item> bdq;
    private static final Logger LOGGER = LoggerFactory.getLogger(BlockingStack.class);

    BlockingStack(int size) {
        bdq = new LinkedBlockingDeque<>(100);
    }

    boolean push(Item newitem) {

        try {
             bdq.putLast(newitem);
             return true;

        } catch (InterruptedException ex) {

            ex.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
    Item pop() {
        try {
            Item popped = bdq.takeLast();
            return popped;
        } catch(InterruptedException ex) {
            LOGGER.debug("{}", ex.getStackTrace());

        }catch (Exception ex) {
            LOGGER.debug("{}", ex.getStackTrace());
        }
        LOGGER.debug("\n Returning null item");
        return null;
    }



}
