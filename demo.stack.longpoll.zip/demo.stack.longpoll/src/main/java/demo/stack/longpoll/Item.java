package demo.stack.longpoll;

import java.net.Socket;

public class Item {
    byte[] payload;
    Socket clientSocket;
    public Item(byte[] payload, Socket clntSock) {
        this.payload = payload;
        this.clientSocket = clntSock;
    }

    public Socket getClientSocket() {
        return clientSocket;
    }

    public void setClientSocket(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    public byte[] getPayload() {
        return payload;
    }

    public void setPayload(byte[] payload) {
        this.payload = payload;
    }
}
