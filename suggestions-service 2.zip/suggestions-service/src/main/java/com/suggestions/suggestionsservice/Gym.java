package com.suggestions.suggestionsservice;

import java.util.List;

public class Gym {
	private String gymId;
	private Location location; 
	private List<WorkOutClass>[] classesInWeek;
	
	Gym(String id, Location location, List<WorkOutClass>[] weeklyClasses) {
		gymId = id;
		this.location = location;
		classesInWeek = weeklyClasses;
	}
	public String getGymId() {
		return gymId;
	}
	public void addClass(WorkOutClass cls) {
		
	}
	public List<WorkOutClass> getClasses(int dayOfWeek) {
		return classesInWeek[dayOfWeek];
	}
	public Location getLocation() {
		return location;
	}


	
}
