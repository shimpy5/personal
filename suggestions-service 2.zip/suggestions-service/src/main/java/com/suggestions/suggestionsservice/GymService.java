package com.suggestions.suggestionsservice;

import java.util.List;

public class GymService {
	
	private List<Gym> gyms;
	private GymService() {
		
	}
	private static GymService instance = new GymService();
	
	public static GymService getInstance() {
		return instance;
	}
	synchronized public void init(List<Gym> gyms) {
		this.gyms = gyms;
	}
	synchronized public void  addGym(Gym obj) {
		gyms.add(obj);
	}
	synchronized public void addClassToGym(String gymId, WorkOutClass wClass) {
	     for (Gym gym: gyms) {
	    	 if(gym.getGymId().equals(gymId)) {
	    		 gym.addClass(wClass);
	    		 break;
	    	 }
	     }
	}

	synchronized public List<Gym> getGyms() {
		// TODO Auto-generated method stub
		return gyms;
	}
	
}
