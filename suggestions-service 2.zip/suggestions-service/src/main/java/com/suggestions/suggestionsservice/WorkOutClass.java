package com.suggestions.suggestionsservice;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class WorkOutClass {
	private long startTime;
	private long endTime;
	private int dayOfWeek;
	
	public WorkOutClass(String startTime, String dayOfWeek) {
		this.startTime = LocalTime.parse(startTime, DateTimeFormatter.ofPattern("h:mm a")).getHour();
		this.endTime = this.startTime + 2;
		this.dayOfWeek = DayOfWeek.valueOf(dayOfWeek).getValue();
	}
	public long getStartTime() {
		return startTime;
	}
	public long getEndTime() {
		return endTime;
	}
	
	public long dayOfClass() {
		return dayOfWeek;
	}
	
}
