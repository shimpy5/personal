package com.suggestions.suggestionsservice;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class RequestData {
	LocalDateTime date;
	Location userLocation;
	int hour;
	int minute;
	int day;

	RequestData(String dateTime, Location userLocation) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd h:mma");
		this.date = LocalDateTime.parse(dateTime, formatter);
		this.hour = date.getHour();
		this.minute = date.getMinute();
		this.day = date.getDayOfWeek().getValue();
		this.userLocation = userLocation;
		
	}
	int getDayOfWeek() {
		return day;
	}
	
	int gethourOfDay() {
		return hour;
	}
	int getMinutes() {
		return minute;
	}
	double getLatitude() {
		return userLocation.getLatitude();
	}
	double getLongitude() {
		return userLocation.getLongitude();
	}
	Location getLocation() {
		return userLocation;
	}
	public void sethourOfDay(int hour) {
		this.hour = hour;
	}
	public void setDayOfWeek(int day) {
		this.day = day;
	}
	public void setMinuteOfHour(int mins) {
		this.minute = mins;
	}
	
}
