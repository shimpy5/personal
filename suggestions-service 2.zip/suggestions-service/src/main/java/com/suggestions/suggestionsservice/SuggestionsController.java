package com.suggestions.suggestionsservice;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;

@RestController
public class SuggestionsController {
	
	final static int DAYINDEX = 3;
	final static int MONDAY = 1;
	final static int FRIDAY = 5;
	final static int classTimeIndex = 4;
	Logger logger = LoggerFactory.getLogger(SuggestionsController.class);
	
	private static Gym buildClassDataForGym(String []tokens) {
		
		Gym gm = null;
		
		if(Pattern.matches(".-.",tokens[DAYINDEX])) {
        	
			String weekDays[] = tokens[DAYINDEX].split("-");
        	
	    	if(weekDays[0].equals("M") &&  weekDays[1].equals("F")) {
	    		
	    		DayOfWeek[] weekdays = DayOfWeek.values();
	    		// Each list in this array keeps classes in sorted order of time for each day of the week
	    		List<WorkOutClass>[] weeklyClasses = (List<WorkOutClass>[])new ArrayList<?>[6];
	    		
				for(int dayIndex = MONDAY; dayIndex <= FRIDAY; dayIndex++) {
					
					weeklyClasses[dayIndex] = new ArrayList<>();
					
					for(int tokenIndex = classTimeIndex; tokenIndex < tokens.length; tokenIndex++) {
						
						WorkOutClass wkClass = new WorkOutClass(tokens[tokenIndex], weekdays[dayIndex-1].toString());
						weeklyClasses[dayIndex].add(wkClass);
					}
					weeklyClasses[dayIndex].sort((a, b)-> { 
						return (int)(a.getStartTime()-b.getStartTime());
					});
				}
				gm = new Gym(tokens[0], new Location(tokens[1], tokens[2]), weeklyClasses);
	    	}
		}
		return gm;
		
	}
	
	@PostConstruct
	private static void setUpData() {
     
		File f = new File("/Users/shimpygupta/suggestions-service/src/main/resources/GymData.txt");
		
		List<Gym> gyms = new ArrayList<>();
	    Scanner scr = null;
	    try {
	    	GymService gymService = GymService.getInstance();
	        scr = new Scanner(f);
	        String scan;
	        while(scr.hasNextLine()) {
	            scan = scr.nextLine();
	            if(scan.length() == 0) {
	            	continue;
	            }
	            String tokens[] = scan.split(",");
	            
	            Gym gymClass = buildClassDataForGym(tokens);
	            gyms.add(gymClass);
	        }
	        gymService.init(gyms);
	    } catch (FileNotFoundException ex) {
	        ex.printStackTrace();
	        
	    } catch (IOException ex) {
	        ex.printStackTrace();
	        
	    } finally {
	        if(scr!=null) scr.close();
	    }
	}

	@GetMapping("/suggestion")
	@ResponseBody
	public List<Suggestion> suggestion(@RequestParam String dateTime, 
			@RequestParam(required = false)String latitude, @RequestParam(required = false)String longitude) {
		
		try {
			logger.trace("RequestReceived");
	        if(dateTime != null) {
	        	
	            if(latitude == null) {
	            	latitude = new String("0.00");
	            }
	            if(longitude == null) {
	            	longitude = new String("0.00");
	            }
	            Location userLocation = new Location(latitude, longitude);
				RequestData reqData = new RequestData(dateTime, userLocation);
				
				// If time goes beyond 5 p.m
				if(reqData.gethourOfDay() >= 17) {
					reqData.setDayOfWeek(reqData.getDayOfWeek()+1);
					reqData.sethourOfDay(8);
					reqData.setMinuteOfHour(0);
				}
				
				if(reqData.getDayOfWeek() <=0 || reqData.getDayOfWeek() > 5) {
					reqData.setDayOfWeek(1);
					reqData.sethourOfDay(8);
					reqData.setMinuteOfHour(0);
				}
				
				
				return new Suggestions().get(reqData);
	        }
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
        return null;
	}

}
