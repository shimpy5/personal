package com.suggestions.suggestionsservice;

public class Suggestion {
	String startTime;
	String endTime;
	String gymId;
	double score;
	Location gymLocation;
	double distanceFromUserLocation;
	Suggestion(String startTime, String endTime, String gymId, double score, Location location) {
		this.startTime = startTime;
		this.endTime = endTime;
		this.gymId = gymId;
		this.score = score;
		this.gymLocation = location;
		this.distanceFromUserLocation = 0.00;
	}
	public String getStartTime() {
		return startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public String getGymId() {
		return gymId;
	}
	public double getScore() {
		return score;
	}
	public double getDistanceFromUserLocation() {
		return distanceFromUserLocation;
	}
	public Location getLocation() {
		return gymLocation;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public void setGymId(String gymId) {
		this.gymId = gymId;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public void setLocation(Location gymlocation) {
		this.gymLocation = gymlocation;
	}
	public void setDistanceFromUserLocation(double distance) {
		this.distanceFromUserLocation = distance;
	}
}
