package com.suggestions.suggestionsservice;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


public class Suggestions {
	public List<Suggestion> scoreCandidatesBasedOnTime(List<WorkOutClass> classes, 
			int hour, int min, String gymId, Location gymLocation, Location userLocation) {
		List<Suggestion> candidates = new ArrayList<>();
		
		for(WorkOutClass cls : classes) {
			
			double score = 0.00;
			DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("hh:mm a");
			
			if(cls.getStartTime() > hour) {
				// Reduce the score by 0.1 if the class time is farther by an hour from requested time
				score = Math.max(0.00, 1.00 - ((cls.getStartTime()-(double)hour)* 0.10)); 
				Suggestion sug = new Suggestion(LocalTime.of((int) cls.getStartTime(), 0).format(FOMATTER).toString(), 
						LocalTime.of((int) cls.getEndTime(),0).format(FOMATTER).toString(),
						gymId, score, gymLocation);
				sug.setDistanceFromUserLocation(gymLocation.distanceFrom(userLocation));
				candidates.add(sug);
			} else if(cls.getStartTime() == hour && min == 0) {
				// Keep the score 1.00 if the class time is on same time as requested time
				score = 1.00;
				Suggestion sug = new Suggestion(LocalTime.of((int) cls.getStartTime(), 0).format(FOMATTER).toString(), 
						LocalTime.of((int) cls.getEndTime(),0).format(FOMATTER).toString(),
						gymId, score, gymLocation);
				sug.setDistanceFromUserLocation(gymLocation.distanceFrom(userLocation));
				candidates.add(sug);
			}
		}
		return candidates;
	}
	
	public List<Suggestion> get(RequestData qData) {
		GymService gymServ = GymService.getInstance();
		List<Suggestion> candidates = new ArrayList<>();
		List<Gym>gyms = gymServ.getGyms();
		
		// Gets the classes on the day of the week and scores them on time
		for(Gym gym : gyms) {
			List<WorkOutClass> classes = gym.getClasses(qData.getDayOfWeek());
			candidates.addAll(scoreCandidatesBasedOnTime(classes, qData.gethourOfDay(), 
					qData.getMinutes(), gym.getGymId(), gym.getLocation(), qData.getLocation()));
		}
		// Bumping up closer locations And sorting on time
		candidates.sort((a,b)-> {
		
			if(a.getScore() == b.getScore()) {
				if(a.getDistanceFromUserLocation() - b.getDistanceFromUserLocation() == 0.00) {
					return 0;
				}
				else if(a.getDistanceFromUserLocation() - b.getDistanceFromUserLocation() > 0.00) {
					return 1;
				}
				return -1;
			} else if(a.getScore() - b.getScore() > 0.0) {
				return -1;
			}
			return 1;
			
		});
		
     return candidates;
		
	}
	
	
}