package com.suggestions.suggestionsservice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuggestionsServiceApplication {
	private static final Logger logger = LoggerFactory.getLogger(SuggestionsServiceApplication.class);

	
	public static void main(String[] args) {
		SpringApplication.run(SuggestionsServiceApplication.class, args);
		logger.info("SuggestionSevice Application Started");
		
	}

}
