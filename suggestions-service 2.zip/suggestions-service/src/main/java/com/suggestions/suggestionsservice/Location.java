package com.suggestions.suggestionsservice;

public class Location {

	double latitude;
	double longitude;
	
	public Location() {
		latitude = 0.00;
		longitude = 0.00;		
		
	}
	public Location(String lat, String longt) {
		latitude = Double.parseDouble(lat);
		longitude = Double.parseDouble(longt);
		
	}
	public Location(double latitude, double longitude) {
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	public double getLatitude() {
		return latitude;
	}
	
	public double getLongitude() {
		return longitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
    
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
   
	public double distanceFrom(Location location2) {
		double x = location2.getLatitude()-latitude;
		double y = location2.getLongitude()-longitude;
		return Math.sqrt(x*x+y*y);
		
	}
	
	
}
