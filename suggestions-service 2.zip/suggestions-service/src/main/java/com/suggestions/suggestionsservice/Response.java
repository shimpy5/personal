package com.suggestions.suggestionsservice;

import java.util.List;

public class Response {

	class Data{
		String gym;
		String time;
	}
	List<Data> payload;
}
