package com.suggestions.suggestionsservice;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;



@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HttpRequestTest {

	@LocalServerPort
	private int port;

	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	public void suggestionReturnsNoLocation() throws Exception {
		// Returns Gym 1 as the first in response		
		ResponseEntity<Suggestion[]> response
		  = restTemplate.getForEntity("http://localhost:" + port 
					+ "/suggestion?dateTime=2021-03-19 8:33AM", Suggestion[].class);
		Suggestion[] objects = response.getBody();
		System.out.println(objects[0].getGymId());
		Assert.isTrue(objects[0].getGymId().equals("Gym 1"), "Value must be Gym 1");
		
	}
	@Test
	public void suggestionReturnsLocation() throws Exception {
		// Returns Gym 1 as the first in response as it opens first	
		ResponseEntity<Suggestion[]> response
		  = restTemplate.getForEntity("http://localhost:" + port 
					+ "/suggestion?dateTime=2021-03-19 8:33AM&latitiude=54.5555&longitude=75.7777", Suggestion[].class);
		Suggestion[] objects = response.getBody();
		Assert.isTrue(objects[0].getGymId().equals("Gym 1"), "Value must be Gym 1");
		
	}
	
	@Test
	public void suggestionReturnsCloserLocationWhenTimesMatch() throws Exception {
		// Returns Closer Location higher in the list when times match
		ResponseEntity<Suggestion[]> response
		  = restTemplate.getForEntity("http://localhost:" + port 
					+ "/suggestion?dateTime=2021-03-19 8:33AM&latitiude=54.5555&longitude=75.7777", Suggestion[].class);
		Suggestion[] objects = response.getBody();
		for(int i = 1; i < objects.length; i++) {
			if(objects[i].score == objects[i-1].score) {
				Assert.isTrue(objects[i].distanceFromUserLocation >= objects[i-1].distanceFromUserLocation, "Closer location must be up in the list since times are same");
			}
		}
		
	}
	
	@Test
	public void suggestionReturnedOnFriday11() throws Exception {
		// Returns Closer Location higher in the list when times match
		ResponseEntity<Suggestion[]> response
		  = restTemplate.getForEntity("http://localhost:" + port 
					+ "/suggestion?dateTime=2021-03-12 11:10AM", Suggestion[].class);
		Suggestion[] objects = response.getBody();
		Assert.isTrue(objects[0].getStartTime().contains("PM"), "Class starts either at Noon or after");
		
	}
	
	@Test
	public void suggestionReturnedOnFriday1_10PM() throws Exception {
		// Returns Closer Location higher in the list when times match
		ResponseEntity<Suggestion[]> response
		  = restTemplate.getForEntity("http://localhost:" + port 
					+ "/suggestion?dateTime=2021-03-12 1:10PM", Suggestion[].class);
		Suggestion[] objects = response.getBody();
		Assert.isTrue(objects[0].getStartTime().contains("02:00 PM"), "Class starts either at Noon or after");
		
	}
	
	@Test
	public void suggestionReturnsWhenTimeIsBeyond5() throws Exception {
		// Returns the gym that starts at earliest the next day
		ResponseEntity<Suggestion[]> response
		  = restTemplate.getForEntity("http://localhost:" + port 
					+ "/suggestion?dateTime=2021-03-18 5:10PM", Suggestion[].class);
		Suggestion[] objects = response.getBody();
		Assert.isTrue(objects[0].getStartTime().equals("09:00 AM"), "Start Time from next day");
		
	}
	
	
	
		
}