Link to be tested
http://localhost:8080/suggestion?dateTime=2021-03-12 01:10PM
or http://localhost:8080/suggestion?dateTime=2021-03-19 8:33AM&latitiude=54.5555&longitude=75.7777

Jar Name: suggestions-service-0.0.1-SNAPSHOT.jar

Run:

java -jar suggestions-service-0.0.1-SNAPSHOT.jar

HttpRequest.java
contains all the testcases

GymData.txt
contains information on all the Gyms, more can be added. Please keep the format.


Please try to keep dates in Monday to Friday of any month.

The overall logic is to setup the data for WorkOutClasses from Monday To Friday for each Gym.
When the endpoint is hit, first gather classes for all gyms for that day and score them based on time. 
The one nearest to requested time gets the maximum score.
The candidates are then sorted on score and if the times match on distance from user location.

Example output:

[{"startTime":"02:00 PM","endTime":"04:00 PM","gymId":"Gym 2","score":0.9,"distanceFromUserLocation":123.12032902189286,"location":{"latitude":34.002827,"longitude":-118.331835}},
{"startTime":"03:00 PM","endTime":"05:00 PM","gymId":"Gym 3","score":0.8,"distanceFromUserLocation":123.13659424587357,"location":{"latitude":33.9988632,"longitude":-118.3498971}},
{"startTime":"03:00 PM","endTime":"05:00 PM","gymId":"Gym 1","score":0.8,"distanceFromUserLocation":123.13747637552031,"location":{"latitude":33.9540723,"longitude":-118.3636729}},
{"startTime":"04:00 PM","endTime":"06:00 PM","gymId":"Gym 2","score":0.7,"distanceFromUserLocation":123.12032902189286,"location":{"latitude":34.002827,"longitude":-118.331835}}]

