package org.example;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //System.out.println("Hello world!");

        /*Scanner sc = new Scanner(System.in);
        int v = sc.nextInt(); // number of vertices
        int e = sc.nextInt(); // number of edges

        Graph g = new Graph(v);

        for (int i = 0; i < e; i++) {
            int src = sc.nextInt();
            int dest = sc.nextInt();
            g.addEdge(src, dest);
        }
        g.print();*/
        WorldLadder2 ladder2 = new WorldLadder2();
        List<String> wordList = List.of("hot","dot","dog","lot","log","cog");
        ladder2.findLadders("hit", "cog", wordList);
        int[][] array = {{4,5}, {3,1}, {2,3}};
        Arrays.sort(array, (a,b) -> a[0] - b[0]);
        for(int arr[] : array) {
            for(int i: arr) {
                System.out.println(i);
                System.out.println(" ");
            }
            System.out.println();
        }

    }
}