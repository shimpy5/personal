package org.example;


/*Array of integers named "blocks" with the size N is given and every integer is the size of the block;
you have 2 frogs that start on one block (either the first one or the "optimal starting block") and the frogs want
to get as far away from each other as possible. The frogs can only jump to the adjacent block if it is at least as big
as the one they are sitting on and can not jump if the adjacent block is smaller than the one they sit on.
The exercise also states that distance between blocks numbered J and K, where J<=K is computed as K - J + 1.
The question is: what is the longest distance that thez can possibly create between each other if thezy chose the
optimal starting block.*/
// Edge conditions
// Monotonically increasing blocks
// Monotonically decreasing blocks
// Same height blocks upto 200,000
public class AngryFrogs {

    /*public int solution(int []blocks) {

        int [][]dp = new int[blocks.length][2];
        //0 for left
        //1 for right
        dp[blocks.length-1][1] = blocks.length-1;
        dp[0][0] = 0;
        int maxDistance = 0;
        for(int i = 0; i < blocks.length-1; i++) {
            int right = i+1;
            while(right < blocks.length && blocks[right] >= blocks[right-1]) {
                right++;
            }
            dp[i][1] = right-1;

            int j = i+1;
            int left = j-1;
            while(left >= 0 && blocks[left] >= blocks[left+1]) {
                left--;
            }
            dp[j][0] = left+1;
            maxDistance = Math.max(maxDistance, dp[i][1]-dp[i][0]+1);
        }
        //print(dp);
        return Math.max(maxDistance, dp[blocks.length-1][1]-dp[blocks.length-1][0]+1);

    }*/

    void print(int [][]dp) {
        for(int i = 0; i < dp.length; i++) {
            //for(int j=0; j < blocks.length; j++) {
            System.out.println("dp["+i+"] " + dp[i][0] + "  " + dp[i][1]);
            //}
        }
    }
   public int solution(int [] blocks) {
        if(blocks.length <= 1) {
            return blocks.length;
        }
        int []left = new int[blocks.length];
        int []right = new int[blocks.length];
        right[blocks.length-1] = blocks.length-1;
        for(int i = blocks.length-2; i >= 0; i--){
            if(blocks[i] <= blocks[i+1]) {
                right[i] = right[i+1];
            } else {
                right[i] = i;
            }
           // System.out.println("right at " + i+ ": " + right[i]);
        }
        left[0] = 0;
        for(int j = 1; j < blocks.length; j++) {
            if(blocks[j] > blocks[j-1]) {
                left[j] = j;
            } else {
                left[j] = left[j-1];
            }
            //System.out.println("left at " + j + ": " + left[j]);
        }
        int distance = 0;
        for(int i = 0; i < blocks.length; i++) {
            distance = Math.max(distance, right[i]-left[i]+1);
        }
        return distance;
    }

    /*public int solution(int[] blocks) {
        int n = blocks.length;
        if (n <= 1) return n;

        // right[i] = farthest right you can reach from i
        // following non-decreasing values
        int[] right = new int[n];
        right[n - 1] = n - 1;
        for (int i = n - 2; i >= 0; i--) {
            right[i] = (blocks[i + 1] >= blocks[i]) ? right[i + 1] : i;
        }

        // left[i] = farthest left you can reach from i
        // going left, each step must be >= current (non-increasing in array order)
        int[] left = new int[n];
        left[0] = 0;
        for (int i = 1; i < n; i++) {
            left[i] = (blocks[i - 1] >= blocks[i]) ? left[i - 1] : i;
        }

        // Find optimal starting block
        int maxDist = 0;
        for (int s = 0; s < n; s++) {
            maxDist = Math.max(maxDist, right[s] - left[s] + 1);
        }
        return maxDist;
    }*/


    public static void main(String args[]) {
        int [] blocks = {2,6,8,5};
        AngryFrogs afr = new AngryFrogs();
        System.out.println(afr.solution(blocks));

        int [] blocks1 = {1,5,5,2,6};
        AngryFrogs afr1 = new AngryFrogs();
        System.out.println(afr1.solution(blocks1));

        int [] blocks2 = {1,1,1,1,1};
        AngryFrogs afr2 = new AngryFrogs();
        System.out.println(afr2.solution(blocks2));

        int [] blocks3 = {1,2,3,4,5};
        AngryFrogs afr3 = new AngryFrogs();
        System.out.println(afr3.solution(blocks3));

        int [] blocks4 = {5,4,3,2,1};
        AngryFrogs afr4 = new AngryFrogs();
        System.out.println(afr4.solution(blocks4));

        int [] blocks5 = new int[2000001];
        for(int i = 0; i < 2000001; i++) {
            blocks5[i] = i+1;
        }
        AngryFrogs afr5 = new AngryFrogs();
        System.out.println(afr5.solution(blocks5));

    }

}
