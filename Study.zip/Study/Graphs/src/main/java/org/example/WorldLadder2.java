package org.example;

import java.util.*;

public class WorldLadder2 {

    public List<List<String>> findLadders(String beginWord, String endWord, List<String> wordList){
        if(!wordList.contains(endWord)) {
            return null;
        }
        Queue<String> pq = new LinkedList<>();
        Map<String, Integer> distance = new HashMap<>();
        Map<String, List<String>> parents = new HashMap<>();
        pq.offer(beginWord);
        distance.put(beginWord, 0);
        String alpha = "abcdefghijklmnopqrstuvwxyz";
        while (!pq.isEmpty()) {
            String word = pq.poll();
            char []array = word.toCharArray();
            for(int i = 0; i < array.length; i++) {
                char original = array[i];
                //System.out.println(i);
                for(int j = 0; j < alpha.length(); j++) {
                    if(array[i] == alpha.charAt(j)) {
                        continue;
                    }
                    array[i] = alpha.charAt(j);
                    String newWord = new String(array);
                    if(wordList.contains(newWord)) {
                        if(!distance.containsKey(newWord)) {
                            distance.put(newWord, distance.getOrDefault(word, -1) + 1);
                            parents.put(newWord, new ArrayList<>(List.of(word)));
                            pq.offer(newWord);  // only enqueue on first disco
                        } else if(distance.get(newWord) == distance.get(word) + 1) {
                            parents.get(newWord).add(word);
                        }
                    }

                }
                array[i] = original;
            }
        }
        //Backtrack
        List<List<String>> wordlists = new ArrayList<>();
        List<String> words = new ArrayList<>();
        constructLists(endWord, beginWord, parents, words, wordlists);
        for(List<String> lst : wordlists) {
            for(String x : lst) {
                System.out.print(" " + x);
            }
            System.out.println();
        }

        return null;
    }
    void constructLists(String endWord, String beginWord, Map<String,
            List<String>> parents, List<String> words, List<List<String>> wordlists) {

        if(beginWord.equals(endWord)) {
            words.add(beginWord);
            List<String> wordl = new ArrayList<>(words);
            Collections.reverse(wordl);
            wordlists.add(wordl);
            return;
        }
        words.add(endWord);
        List<String> older = parents.get(endWord);
        for(String oldParent : older){
            constructLists(oldParent, beginWord, parents, words, wordlists);
            words.remove(words.size() - 1);
        }
    }
}

