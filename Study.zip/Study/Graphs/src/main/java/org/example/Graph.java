package org.example;

public class Graph {
    private int [][] adjacencyMatrix;
    private int vertices;

    public Graph(int vertices) {
        this.vertices = vertices;
        adjacencyMatrix = new int[vertices][vertices];
    }

    public void addEdge(int u, int v) {
        //System.out.printf("I am here");
        adjacencyMatrix[u][v] = 1;
    }
    public void print() {
        //System.out.printf("I am in print");
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        for(int i = 0; i < vertices; i++) {
            for(int j = 0; j < vertices; j++) {
                System.out.printf("%d", adjacencyMatrix[i][j]);
                System.out.print(" ");
            }
            System.out.println();
        }
    }
}
