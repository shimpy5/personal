package org.example.pubsub;

import org.example.Subscriber;

public class Subscriber1 implements Subscriber {
    private String uuid;

    public Subscriber1(String uuid) {
        this.uuid = uuid;
    }

    public void onMessage(String message){
        System.out.println(message + " " + uuid);
    }
    public String getId() {
        return uuid;
    }
}