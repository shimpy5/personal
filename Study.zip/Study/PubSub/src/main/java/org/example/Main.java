package org.example;

import org.example.pubsub.PubSubBrokerImpl;
import org.example.pubsub.Subscriber1;

import java.util.UUID;

//Important is pubsub broker is implemented
//PubSub broker keeps a list of subscribers for each topic
//There is a queue per subscriber that is handled by a worker thread(newSingleThreadExecutor()):
// -keeps the messages inorder from different topics
// -keeps the distribution of messages async.
// Unsubscribe from a topic for a subscriber : The worker thread can be shutdown immediately
// or after the subscriber has unsubscribed from all the topics after 5 minutes.
// Message should have : subscriberId, payload, timestamp.
// Fanout with per subscriber queue design.
// Fanout with every topic owning the queue and pushing a message
// on all the subscribers registered for the topic has issues with ordering of messages received by
// subscribers and a slow subscriber can delay other subscribers
// when the message is being pushed onto.
public class Main {
    public static void main(String[] args) {
        try {
            Subscriber1 sub1 = new Subscriber1(UUID.randomUUID().toString());
            Subscriber1 sub2 = new Subscriber1(UUID.randomUUID().toString());

            PubSubBrokerImpl pubsub = new PubSubBrokerImpl();
            pubsub.subscribe("news.sports", sub1);
            pubsub.subscribe("news.sports", sub2);
            pubsub.subscribe("news.sports.tennis", sub1);
            pubsub.publish("news.sports", "Is this sports topic?");
            for(int i = 0; i < 10; i++) {
                pubsub.publish("news.sports", "The sports topic message" +
                        i + " ");
                if(i == 5) {
                    pubsub.unsubscribe("news.sports", sub2);
                }
            }
            pubsub.publish("news.sports.tennis", "Steffi was the champion");

            Thread.sleep(5000);
            pubsub.publish("news.sports.tennis", "Now Monica is the champion");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}