package org.example;

public interface PubSubBroker {
    void subscribe(String topic, Subscriber s);
    void unsubscribe(String topic, Subscriber s);
    void publish(String topic, String message);
}
