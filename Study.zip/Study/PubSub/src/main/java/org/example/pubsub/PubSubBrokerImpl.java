package org.example.pubsub;

import org.example.PubSubBroker;
import org.example.Subscriber;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.*;

public class PubSubBrokerImpl implements PubSubBroker {
    ConcurrentHashMap<String, List<Subscriber>> topicSubscriber;
    ConcurrentHashMap<Subscriber, ExecutorService> subQueue;
    ConcurrentHashMap<Subscriber, List<String>> subTopics;
    ScheduledExecutorService cleaner = Executors.newSingleThreadScheduledExecutor();
    //ConcurrentHashMap<String, ExecutorService> fanout; No ordering amongst subscribers

    public class Task implements Runnable {

        String message;
        List<Subscriber> subscribers;

        Task(String message, List<Subscriber> subscribers) {
            this.message = message;
            this.subscribers = subscribers;
        }
        @Override
        public void run() {
           // while(true) {
                for (Subscriber subscriber : subscribers) {
                    subscriber.onMessage(message);
                }
            //}

        }
    }
    public PubSubBrokerImpl() {
        this.topicSubscriber = new ConcurrentHashMap<>();
        this.subQueue = new ConcurrentHashMap<>();
        this.subTopics = new ConcurrentHashMap<>();
    }
    public void subscribe(String topic, Subscriber s) {
        List<Subscriber> subscribers = topicSubscriber.computeIfAbsent(topic,
                    z -> new CopyOnWriteArrayList<>());
        subscribers.add(s);
        subQueue.putIfAbsent(s, Executors.newSingleThreadExecutor());
        subTopics.computeIfAbsent(s, z -> new CopyOnWriteArrayList<>()).add(topic);

    }
    public void unsubscribe(String topic, Subscriber s) {
        //ExecutorService srvc = subQueue.get(s);
        //if(srvc != null) {
        //  srvc.shutdown();
        //}
        List<Subscriber> subs = topicSubscriber.get(topic);
        if (subs != null) {
            subs.remove(s);
        }
        List<String> topics = subTopics.get(s);
        if (topics != null) {
            topics.remove(topic);
            if(topics.isEmpty()) {
                cleaner.schedule(() -> {
                    ExecutorService srvc = subQueue.get(s);
                    if (srvc != null) {
                        srvc.shutdown();
                    }
                }, 5, TimeUnit.SECONDS);
            }
        }
    }
    public void publish(String topic, String message) {
        List<Subscriber> subscribers = topicSubscriber.get(topic);
        /*if(subscribers != null) {
            ExecutorService srvc = subQueue.getOrDefault(topic, null);
            if(srvc != null) {
                for(Subscriber sub : subscribers) {
                    srvc.submit(() -> sub.onMessage(message));
                }
            }
        }*/
        if(subscribers != null) {
            for(Subscriber sub : subscribers) {
                ExecutorService srvc = subQueue.get(sub);
                if(srvc != null) {
                    srvc.submit(() -> sub.onMessage(message));
                }
            }
        }


    }
}
