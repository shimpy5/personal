package org.example.pusubpull;

public interface Subscriber {
    void onMessage(String topic, String message);
}
