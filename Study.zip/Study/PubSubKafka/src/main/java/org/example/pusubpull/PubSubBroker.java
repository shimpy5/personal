package org.example.pusubpull;

import java.util.concurrent.Flow;

public interface PubSubBroker {
    void subscribe(String topic, ConsumerGroup consumers, Subscriber sub);
    void unsubscribe(String topic, ConsumerGroup consumers, Subscriber sub);
    void publish(String topic, String message);
}
