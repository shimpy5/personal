package com.newrelic.codingchallenge;


public class Main {

    public static void main(String[] args) {

        System.out.println("Starting up server ....");

        // Add your code here
    }
}