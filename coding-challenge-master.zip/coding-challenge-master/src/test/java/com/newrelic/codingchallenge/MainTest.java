package com.newrelic.codingchallenge;

import org.junit.Test;

public class MainTest {

    @Test
    public void test() {

        // Test something here (optional)
        System.out.println("Testing");
    }
}