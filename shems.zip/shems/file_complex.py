import csv

# List of CSV files
csv_files = ['jan_1.csv', 'feb_1.csv', 'march_1.csv', 'april_1.csv', 'may_1.csv']

# previous_yearsshems_ids array of location IDs
previous_yearsshems_location_ids = ["835fdfcf-0e9c-47ad-8dec-4c774070534f",
            "7e5ec512-1516-4ff4-9cff-b12a9434eb0e",
            "b1212d1e-b6bb-4f15-bf01-a416cd263f0f",
            "3b5ea20c-f5ca-4792-a573-fbe874bad1b4",
            "bd4d86ca-078c-4a7b-a998-f7048c56904f",
            "92425957-3050-42d2-a185-efde5df00b43",
            "8a7d3e81-30ef-43b4-8a9e-7f69812aaa31",
            "d6959b4f-b641-423c-9807-18066f66c806",
            "e7eb4db9-2e5a-4d0e-8716-9878e80e21d8",
            "fc503fa6-5e13-4aa9-8791-f0951490793b",
            "43ed60a3-ac46-49b8-beb8-06b33640582b",
            "7fdd7759-3318-4ebd-a55b-296565df918b",
            "ea665ae9-7fd5-4aee-b737-0fd21db55595",
            "dc2df12a-e443-4982-8dd1-a6674ed4cd7d",
            "31a594f7-551e-4bb0-b3b4-85f4f189b646",
            "88638ca3-1701-4070-a2ce-91f3493395f1",
            "97d6c775-e719-4c93-b30b-bb7fa6a58028",
            "3ee77294-c6fc-46ac-a5b0-a5129cf22eb7",
            "5a5a2325-c087-4b4b-bd3d-c6fbf51c8df2",
            "a388ab7e-bd42-4db4-9de6-ca6a8651a3d7",
            "f2440053-3059-4bdb-bde1-16771830d1e0",
            "fa9bbc6a-ccf1-4421-86c9-990003d9eb5b",
            "fcb0f5a4-87e6-42c3-816c-ebf6f8305425",
            "867a995f-a430-4c2f-bc69-58d3cd6d1a27",
            "ca51caf6-70ea-4ab9-975f-3b4ec419fad2",
            "fb81c40a-6788-4101-9f8d-a86b33a89b14",
            "acb5c036-bd47-4869-bb84-75ba40813488",
            "9eff52b3-939f-42f7-b67a-1c0749233444",
            "05a38ebf-e1c7-4b23-8e76-c0429e820800",
            "75eafb96-ddf7-482e-b4dd-3f10b856084c",
            "941739c3-50fc-4081-a1c9-52350cdbaee4",
            "e5c6b407-6f03-4937-bf06-aa2271c925da",
            "e0f40944-1e3d-40a0-b3fc-b7d54332f1e1",
            "0c2dcf0a-6e94-4a5e-9795-ddefde554394",
            "5b46e47c-ec04-4969-8996-11eb4f44cbdf",
            "e58594d3-6200-4431-869a-74c8dbd604ea",
            "52b54499-c316-431e-ba41-c67de53a4237",
            "440e31a6-015d-46f8-baf7-67c7276c4a61",
            "d5215d8d-703e-4161-bfb7-0376fad313c9",
            "3594e1a5-e388-49a0-830e-d964c784f446",
            "6f3aea47-fb70-4266-8859-d36d73c70eb8",
            "787e3157-4d03-41a7-9777-06a7101fb2ef",
            "81b1080d-1dd7-4664-9042-225cd10f4ac0",
            "eac051c1-6188-4b2f-86cd-6d3514dffe0f",
            "9981bdc0-22df-4474-8cad-455255ebb894",
            "02e10bca-0195-424d-a639-fcb20b3edc8f",
            "8df4e9f0-2025-4c67-ab3e-c007c4b210c9",
            "1a33cd8f-9aa2-451c-933a-526e330efb83",
            "fb336cc4-231d-4cf8-af0a-6ef251e743e4",
            "0f630f1c-8f75-4553-a756-26a955451aff",
            "ac6574a5-28ae-41a7-8bf2-106f3fd494c1",
            "2748d9ba-f070-4c50-a3cc-49186ea3c626",
            "b2c9143b-c374-46a5-8be3-63696afccf3b",
            "e4ad3414-0577-475a-8b06-61506fb28d80",
            "7aaf4bff-63e8-4a52-b71e-1b6861561469",
            "a595ded0-31a1-451f-be3e-4a79534401b8",
            "ae7ac5dd-8f49-4e75-9107-080bbc7c0fa0",
            "29f10c76-1972-4c97-abd8-855938cc1953",
            "881275b3-7835-4433-aee9-4fc07555765d",
            "37920cd6-e3ab-4836-ab4a-686a0cb54cd7",
            "6198ad17-6bc5-49f5-817f-53b0f1ad4138",
            "64eec56c-0eb2-452b-bdc7-adc590ccdebf",
            "e8c8f185-54c1-4e73-9752-63de55ca13c2",
            "5387fe8e-4b8b-45a8-acf8-32793206c339",
            "02426c4e-bea7-428b-866a-42c90585e452",
            "2fb4fe99-f049-4bef-a51e-4f2f75d98f20",
            "4267d12a-aa5b-411c-baa5-8916fe4e8847",
            "abc5ea8d-3d32-4f1c-92a6-6c4b3c4cf3ff",
            "bc1813cb-c6e9-436c-8770-debeb9f4bd5b",
            "b71bf043-70f9-4798-b792-7875d239007d",
            "5925df20-7eac-42c2-b3c9-a3f4bab4fd64",
            "1b4c2218-0cca-4de4-84f6-42fdf312f7f6",
            "8156d552-fd49-4be8-8134-06874a9297f2",
            "369eccd1-5b52-47fa-8e8a-3e40d06eeac0",
            "7c70c636-85d0-42d6-ad04-5725f0a11644",
            "d4cf8b98-344f-417a-8098-2d27e0872286",
            "0d800f08-5982-47b6-9445-3f9319a28e6c",
            "59257732-ae3e-4fdf-9015-b97a5c9a89c2",
            "9ab07509-e37a-48aa-bb32-ea096f6f1198",
            "df44d076-0b73-4fd9-9245-4aa8cd7b2d25",
            "f17b6b01-fe68-4167-8e52-ee79ee223e68",
            "ad437adc-b69c-49ff-bc22-77a0f5b04110",
            "b31ff93f-06f3-4777-bfdb-d73b447dbc9d",
            "ae2d3b0f-7076-434d-837f-86b1f30abddd",
            "5c125168-5a8d-47cd-a4ad-31902323d8e9",
            "2b9f830a-078b-4ecd-8c13-f539194b1000",
            "16e8b014-79c3-47b2-922d-1257063aa367",
            "2f99713e-6540-4282-b96f-4704f7dd5759"]

# Initialize a dictionary to store the sets and counts for each CSV file
location_ids_dict = {}

# Process each CSV file
for csv_file in csv_files:
    # Initialize an empty set for the current CSV file
    location_ids = set()

    # Open the CSV file and parse the data
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)

        # Skip the header row
        next(reader)

        # Iterate over each row and add the location_id to the set
        for row in reader:
            location_id = row[0]
            location_ids.add(location_id)

    # Store the set and count for the current CSV file in the dictionary
    location_ids_dict[csv_file] = {
        'set': location_ids,
        'count': len(location_ids)
    }

# Add the previous_yearsshems_ids location IDs to the dictionary
#location_ids_dict['previous_yearsshems_ids'] = {
#    'set': set(previous_yearsshems_location_ids),
#    'count': len(previous_yearsshems_location_ids)
#}

# Find the common location IDs present in all sources
common_location_ids = set.intersection(*[data['set'] for data in location_ids_dict.values()])

# Print the distinct location IDs for each source
for source, data in location_ids_dict.items():
    print("Source:", source)
    print("Count:", data['count'])
#    print("Distinct Location IDs:", data['set'])
    print()

# Print the count and common location IDs
print("Common Location IDs Count:", len(common_location_ids))
print("Common Location IDs:", common_location_ids)
