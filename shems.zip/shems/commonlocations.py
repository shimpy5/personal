import csv

# List of CSV files
csv_files = ['jul_1.csv']

# previous_yearsshems_ids array of location IDs
previous_yearsshems_location_ids = ["05a38ebf-e1c7-4b23-8e76-c0429e820800",
	"8156d552-fd49-4be8-8134-06874a9297f2",
	"81b1080d-1dd7-4664-9042-225cd10f4ac0",
	"eac051c1-6188-4b2f-86cd-6d3514dffe0f",
	"e7eb4db9-2e5a-4d0e-8716-9878e80e21d8",
	"3594e1a5-e388-49a0-830e-d964c784f446",
	"f17b6b01-fe68-4167-8e52-ee79ee223e68",
	"8a7d3e81-30ef-43b4-8a9e-7f69812aaa31",
	"fb81c40a-6788-4101-9f8d-a86b33a89b14",
	"37920cd6-e3ab-4836-ab4a-686a0cb54cd7",
	"02426c4e-bea7-428b-866a-42c90585e452",
	"e8c8f185-54c1-4e73-9752-63de55ca13c2",
	"1b4c2218-0cca-4de4-84f6-42fdf312f7f6",
	"2fb4fe99-f049-4bef-a51e-4f2f75d98f20",
	"ad437adc-b69c-49ff-bc22-77a0f5b04110",
	"ca51caf6-70ea-4ab9-975f-3b4ec419fad2",
	"d4cf8b98-344f-417a-8098-2d27e0872286",
	"43ed60a3-ac46-49b8-beb8-06b33640582b",
	"dc2df12a-e443-4982-8dd1-a6674ed4cd7d",
	"9a9ed66f-0528-4899-93d9-c5a5df7f57de",
	"78319975-5783-4ea4-be8e-0e8ec5cc5d53",
	"5276b5bb-f766-4acd-b362-05f227124519",
	"445a40d4-ea2f-4011-ac58-55610cf186a4",
	"3c9d3d4d-af17-45e4-b65e-b3e65c58dd83",
	"bb6f804b-5a61-419e-bcab-456602530b25",
	"f2d701a7-a50d-485c-a3f7-27d152e39eae",
	"956b4ecd-29c2-4f8c-9afe-d254013991ec",
	"1ef8b521-6a45-403a-9f55-60c6d06233e0",
	"1e7ccdde-b1ee-4372-9b02-477cab87f15a",
	"d9fceae9-7446-44c1-afa4-c3d831f67fe3"]

# Initialize a dictionary to store the sets and counts for each CSV file
location_ids_dict = {}

# Process each CSV file
for csv_file in csv_files:
    # Initialize an empty set for the current CSV file
    location_ids = set()

    # Open the CSV file and parse the data
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)

        # Skip the header row
        next(reader)

        # Iterate over each row and add the location_id to the set
        for row in reader:
            location_id = row[0]
            location_ids.add(location_id)

    # Store the set and count for the current CSV file in the dictionary
    location_ids_dict[csv_file] = {
        'set': location_ids,
        'count': len(location_ids)
    }

# Add the previous_yearsshems_ids location IDs to the dictionary
location_ids_dict['previous_yearsshems_ids'] = {
    'set': set(previous_yearsshems_location_ids),
    'count': len(previous_yearsshems_location_ids)
}

# Find the common location IDs present in all sources
common_location_ids = set.intersection(*[data['set'] for data in location_ids_dict.values()])

# Print the distinct location IDs for each source
for source, data in location_ids_dict.items():
    print("Source:", source)
    print("Count:", data['count'])
#    print("Distinct Location IDs:", data['set'])
    print()

# Print the count and common location IDs
print("Common Location IDs Count:", len(common_location_ids))
print("Common Location IDs:", common_location_ids)
