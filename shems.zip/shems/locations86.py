import pandas as pd
import numpy as np
from datetime import datetime
from datetime import timedelta

df = pd.read_csv('locations86.csv', usecols=['location_id'])
#count = 0
#sum = 0
df.to_csv('locations.csv')
#for index, row in df.iterrows():
#        str = df['name'][index]
#        str2 = 'Night'
#        str3 = 'One sleeping one awake'
#        str4 = 'Away'
#        str5 = 'Sleep'
#        if str == str2 or str == str3 or str == str4 or str == str5:
#           if df['exeEvent_locid'][index-1] == df['exeEvent_locid'][index] and (df['name'][index-1] == 'Home' or df['name'][index-1] == 'Sleep' or df['name'][index-1] == 'Away'):
#               print(df['exeEvent_locid'][index-1])
#              print('\n')
#              print(df['location_id'][index],df['device_id'][index], df['command'][index], df['servertime'][index])
#              print('\n \n')
#               count = count+1
#               format = '%Y-%m-%dT%H:%M:%S'
#               ts1 = df['exeEvent_ts'][index-1]
#               ts2 = df['exeEvent_ts'][index]
#               datetimeobj1 = datetime.strptime(ts1[:19], format)
#               datetimeobj2 = datetime.strptime(ts2[:19], format)
#               timestampdiff = datetimeobj1 - datetimeobj2
#               sum = sum + round(timestampdiff.total_seconds()/3600)
#               print("\n Index being used ",index, "hours = ", round(timestampdiff.total_seconds()/3600))
               #print(datetimeobj1.time)
#print(sum)
#print(count)
#print(sum/count)

