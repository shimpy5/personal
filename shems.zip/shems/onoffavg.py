import pandas as pd
import numpy as np
import csv
from datetime import datetime

csv_files = ['sqllab_light_may13.csv', 'sqllab_may_7-9.csv', 'sqllab_light_may10-12.csv']
# 'sqllab_may_4-6.csv', 'sqllab_light_may2-3.csv', 'sqllab_light_apr-may.csv']
locationtime = {}
for csv_file in csv_files:
 print("\n CSV files :", csv_file)
 df = pd.read_csv(csv_file, usecols=['location_id', 'device_id', 'command', 'servertime'])
 count = 0
 sum = 0
 for index, row in df.iterrows():
       str = df['command'][index]
       str2 = 'on'
       if str == str2:
           if df['location_id'][index-1] == df['location_id'][index] and df['location_id'][index] == df['location_id'][index] and df['device_id'][index-1] == df['device_id'][index] and df['command'][index-1] == 'off' :
#              print(df['location_id'][index-1],df['device_id'][index-1], df['command'][index-1], df['servertime'][index-1])
#              print('\n')
#              print(df['location_id'][index],df['device_id'][index], df['command'][index], df['servertime'][index])
#              print('\n \n')
#              count = count+1
               format = '%Y-%m-%dT%H:%M:%S'
               ts1 = df['servertime'][index-1]
               ts2 = df['servertime'][index]
               datetimeobj1 = datetime.strptime(ts1[:19], format)
               datetimeobj2 = datetime.strptime(ts2[:19], format)
               timestampdiff = datetimeobj1 - datetimeobj2
               val = locationtime.get(df['device_id'][index])
               if val != None:
                  val = val+round(timestampdiff.total_seconds()/60)
               else :
                  val = round(timestampdiff.total_seconds()/60)
               locationtime[df['device_id'][index]] = val                                  
#               delta = timedelta(timestampdiff.hours, timestampdiff.minutes, timestampdiff.seconds)
           #    sum = sum + round(timestampdiff.total_seconds()/60)
           #    print("\n Device_id = ",df['device_id'][index], " minutes = ", round(timestampdiff.total_seconds()/60))
               #print(datetimeobj1.time)
print("\n\n")
#for k,v in locationtime.items():
  #print("Key DeviceId = ", k, "avg minutes = ",v)
keys = list(locationtime.keys())
values = list(locationtime.values())
result = [x/7 for x in values]
result.sort()
#sorted_value_index = np.argsort(values)
#print(sorted_value_index)
print(result)
#sorted_dict = {keys[i]: values[i] for i in sorted_value_index}


with open('daily1.csv', 'w') as f:
#   f.write("%s,%s\n"%("device_id, "minutes"))
   for k in result:
        f.write("%s\n"%(k))


