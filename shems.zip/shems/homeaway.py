import pandas as pd
import numpy as np
from datetime import datetime
from datetime import timedelta

df = pd.read_csv('sqllab_light_may13.csv', usecols=['exeEvent_locid', 'name', 'eventType', 'exeEvent_ts'])
count = 0
sum = 0
#print(df)
locationhrsperweek = {}
locawaytimerevent = {}
locawaydeviceevent = {}
for index, row in df.iterrows():
        str = df['name'][index]
        str2 = 'Night'
        str3 = 'One sleeping one awake'
        str4 = 'Away'
        str5 = 'Sleep'
        print("Index is = \n", index)
        if str == str2 or str == str3 or str == str4 or str == str5:
           if df['exeEvent_locid'][index-1] == df['exeEvent_locid'][index] and (df['name'][index-1] == 'Home' or df['name'][index-1] == 'Sleep' or df['name'][index-1] == 'Away'):
               print(df['exeEvent_locid'][index-1])
#              print('\n')
#              print(df['location_id'][index],df['device_id'][index], df['command'][index], df['servertime'][index])
#              print('\n \n')
#               count = count+1
               format = '%Y-%m-%dT%H:%M:%S'
               ts1 = df['exeEvent_ts'][index-1]
               ts2 = df['exeEvent_ts'][index]
               datetimeobj1 = datetime.strptime(ts1[:19], format)
               datetimeobj2 = datetime.strptime(ts2[:19], format)
               print("Location = ", df['exeEvent_locid'][index-1], "timetampdiff = ", (datetimeobj1 - datetimeobj2).total_seconds()/3600)
               timestampdiff = datetimeobj1 - datetimeobj2
               if df['eventType'][index] == 'DEVICE_EVENT' :
                     val = locawaydeviceevent.get(df['exeEvent_locid'][index])
                     if val != None:
                        val = val+(timestampdiff.total_seconds())/3600
                     else :
                        val = 0
                     locawaydeviceevent[df['exeEvent_locid'][index-1]] = val
               elif df['eventType'][index] == 'TIMER_EVENT' :
                     val = locawaytimerevent.get(df['exeEvent_locid'][index])
                     if val != None:
                        val = val+(timestampdiff.total_seconds())/3600
                     else :
                        val = 0
                     locawaytimerevent[df['exeEvent_locid'][index-1]] = val
               else :
                  val = locationhrsperweek.get(df['exeEvent_locid'][index-1])
#                 print("Val = \n", val)
                  if val != None:
                     val = val+(timestampdiff.total_seconds())/3600
#                    print("Val = \n", val)
                  else :
                     val = 0
                  locationhrsperweek[df['exeEvent_locid'][index-1]] = val
               #sum = sum + round(val.total_seconds()/3600)
               # print("\n  Index being used ",index, "hours = ", round(timestampdiff.total_seconds()/3600))
               #print(datetimeobj1.time)
for k,v in locationhrsperweek.items():
  print("Location = ", k, "avg hours = ",v)

for k,v in locawaytimerevent.items():
  print("Location Timer = ", k, "avg hours = ",v)

for k,v in locawaydeviceevent.items():
  print("LocationAway = ", k, "avg hours = ",v)
#print(count)
#print(sum/count)

